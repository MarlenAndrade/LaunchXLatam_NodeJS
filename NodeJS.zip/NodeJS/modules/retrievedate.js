// Este módulo lo creamos y solo devuelve la fecha actual DEL SERVER
exports.RetrieveDate = function() {
    return Date();
}